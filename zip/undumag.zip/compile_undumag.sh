gfortran -c -O2 -cpp -fd-lines-as-comments -Wno-align-commons -ffixed-line-length-none -finit-local-zero -funroll-loops mshcern.f
gfortran -c -O2 -cpp -fd-lines-as-comments -Wno-align-commons -fopenmp -fcheck=bounds -ffixed-line-length-none -finit-local-zero -funroll-loops mshplt.f

gfortran -c -O2 -cpp -fd-lines-as-comments -Wno-align-commons -fopenmp -fcheck=bounds -ffixed-line-length-none -finit-local-zero -funroll-loops undumag_modules.f
gfortran -c -O2 -cpp -fd-lines-as-comments -Wno-align-commons -fopenmp -fcheck=bounds -ffixed-line-length-none -finit-local-zero -funroll-loops util.f

gfortran -c -O2 -cpp -fd-lines-as-comments -Wno-align-commons -fopenmp -fcheck=bounds -ffixed-line-length-none -finit-local-zero -funroll-loops urad.f
gfortran -c -O2 -cpp -fd-lines-as-comments -Wno-align-commons -fopenmp -fcheck=bounds -ffixed-line-length-none -finit-local-zero -funroll-loops undumag_subroutines.f
gfortran -O2 -cpp -fd-lines-as-comments -Wno-align-commons -fopenmp -fcheck=bounds -ffixed-line-length-none -finit-local-zero -funroll-loops -o undumag.exe undumag_main.f *.o
